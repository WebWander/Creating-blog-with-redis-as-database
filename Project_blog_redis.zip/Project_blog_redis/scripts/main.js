// document.getElementById('createPostForm').addEventListener('submit', function(event) {
//     event.preventDefault();
//     const formData = new FormData(this);
//     fetch('/create-post', {
//       method: 'POST',
//       body: formData,
//       credentials: 'include'
//     }).then(response => response.json())
//       .then(data => {
//         if (data.success) {
//           // Refresh posts or add the new post to the DOM
//           fetchPosts();
//         }
//       }).catch(error => console.error('Error creating post:', error));
//   });
  



document.addEventListener('DOMContentLoaded', function() {
    // Check if the user is logged in
    fetch('/check-session', { credentials: 'include' })
      .then(response => response.json())
      .then(data => {
        if (data.isLoggedIn) {
          // User is logged in, update UI and fetch posts
          updateUIForLoggedInUser(data.user);
          fetchPosts();
        } else {
          // User is not logged in, redirect to login page or show login form
          redirectToLogin();
        }
      })
      .catch(error => {
        console.error('Error:', error);
      });
  });
  
  function updateUIForLoggedInUser(username) {
    const userElement = document.getElementById('user');
    userElement.textContent = `${username} logged in`;
    userElement.style.position = 'absolute';
    userElement.style.right = '10px'; // Add a bit of margin
    userElement.style.top = '10px';
    userElement.style.color = 'white'; // So it's visible against the background
  }

  console.log(updateUIForLoggedInUser(data.user));
  
  function fetchPosts() {
    fetch('/blogposts', { credentials: 'include' })
      .then(response => response.json()) // Make sure to parse the response as JSON
      .then(data => {
        const postsContainer = document.getElementById('postsList');
        postsContainer.innerHTML = ''; // Clear any existing content
        if (data.posts && data.posts.length > 0) {
          data.posts.forEach(post => {
            const postElement = document.createElement('li');
            postElement.innerHTML = `
              <h2>${post.title}</h2>
              <p>${post.text}</p>
              <p>Author: ${post.author}</p>
              <p>Date: ${new Date(post.date).toLocaleString()}</p>
            `;
            if (post.author === data.user) {
                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Delete';
                deleteButton.onclick = function() {
                  fetch('/delete-post', {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ postId: post.id }),
                    credentials: 'include'
                  }).then(response => {
                    if (response.ok) fetchPosts(); // Refresh posts after deletion
                  }).catch(error => console.error('Error deleting post:', error));
                };
                postElement.appendChild(deleteButton);
                }
            postsContainer.appendChild(postElement);
            });
        } else {
          // Display a message if there are no posts
          document.getElementById('noPostsMessage').style.display = 'block';
        }
      })
      .catch(error => {
        console.error('Error fetching posts:', error);
      });
  }
  
  function redirectToLogin() {
    alert('You will be redirected to the login page in 5 seconds.');
    setTimeout(() => {
      window.location.href = '/login';
    }, 5000);
  }
  