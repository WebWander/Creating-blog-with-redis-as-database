import bcrypt from "bcrypt";
import bodyParser from "body-parser";
import cors from 'cors';
import express from "express";
import { createClient } from "redis";
import session from "express-session";
import RedisStore from "connect-redis";
import path from "path";
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));


const PORT = process.env.PORT || 8001;

const app = express();
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));




app.use(cors({
  origin: 'http://localhost:8001', // or whatever your client-side URL is
  credentials: true, // to allow cookies to be sent
}))

//app.use(bodyParser.json());

const redisURL = "redis://127.0.0.1:6379"
// Initialize client
let redisClient = createClient(redisURL);
redisClient.connect(console.log(`Connected to redis`)).catch(console.error);
// redisClient.on('error', (err) => {
//   console.error('Redis Error:', err);
// });


// Initialize store
const redisStore = new RedisStore({
  client: redisClient,
  prefix: "posts",
});

// Initialize session storage
app.use(
  session({
    secret: "MySecret",
    cookie: { maxAge: 1000 * 60 *60 * 24, secure: false, sameSite: "none" },
    resave: false,
    saveUninitialized: false,
    store : redisStore,
  })
);

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});



app.get('/', (req, res) => {
  res.render('index', { user: req.session.username || null });
});





app.get('/check-session', (req, res) => {
  if (req.session.isLoggedIn) {
    res.json({ isLoggedIn: true, user: req.session.username });
  } else {
    res.json({ isLoggedIn: false });
  }
});



app.post('/register', async (req, res) => {
  const { username, password } = req.body;

  // Check if username or password is missing
  if (!username || !password) {
      return res.status(400).send('Username and password are required');
  }

  try {
      // Check if username is already taken
      const existingUser = await redisClient.get(`user:${username}`);
      if (existingUser) {
          return res.status(409).send('Username is already taken');
      }

      // If username is unique, salt and hash the password and register the user
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);
      await redisClient.set(`user:${username}`, hashedPassword);
      res.status(201).send('User registered successfully');
  } catch (err) {
      res.status(500).send('Error registering user');
  }
});

app.get('/register', (req, res) => {
  res.render('pages/register', { user: req.session.username || null });
});


app.get('/login', (req, res) => {
  // Render the login page. You might also want to pass in any messages or errors if you have a system for that.
  res.render('pages/login', { user: req.session.username || null });
});

//User Login
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
      return res.status(400).send('Username and password are required.');
  }

  try {
      const hashedPassword = await redisClient.get(`user:${username}`);
      console.log(`Hashed password from Redis for ${username}:`, hashedPassword);

      //if (!hashedPassword) return res.status(400).send('User not found');

      const isMatch = await bcrypt.compare(password, hashedPassword);
      console.log(`Password match for ${username}:`)
  
      if (isMatch) {
          // Set user information in session
          req.session.isLoggedIn = true;
          req.session.user = username;

          // Fetch blog posts from Redis
          const posts = await fetchBlogPosts(); // Make sure to await this call
          res.render('pages/blogposts', {
            user: req.session.user, // Pass the user object
            posts: posts // Pass the posts array
        });

  
          // Set session timeout (adjust the maxAge value as needed)
          req.session.cookie.maxAge = 60 * 60 * 1000; // 1 hour
      } else {
          res.status(401).send('Invalid credentials');
      }
  } catch (err) {
      console.error('Error logging in user:', err);
      res.status(500).send('Error logging in user');
  }
});

async function fetchBlogPosts() {
  // Assuming blog posts are stored with keys like "blogpost:1", "blogpost:2", etc.
  const postKeys = await redisClient.keys('blogposts:*');
  const posts = [];
  for (const key of postKeys) {
    const post = await redisClient.hGetAll(key);
    // Extract the post ID from the key
    const postId = key.split(':')[1];
    posts.push({ id: postId, ...post });
  }
  return posts;
}

// Post a blog entry

app.post('/create-post', async (req, res) => {
  // Check if the user is logged in
  if (!req.session.isLoggedIn) {
    return res.status(401).json({ error: 'User not logged in' });
  }

  // Extract the fields from the request body
  const { title, text, author, date } = req.body;

  try {
    // Generate a new post ID
    const postId = await redisClient.incr('postId');

    // Convert the date from the form to ISO format if necessary
    // If the date is not in the form, use the current date
    const formattedDate = date ? new Date(date).toISOString() : new Date().toISOString();

    // Save the post details to Redis
    await redisClient.sendCommand([
      'HMSET', 
      `blogposts:${postId}`, 
      'title', title, 
      'text', text, 
      'author', author, // Use the author from the form
      'date', formattedDate, // Use the date from the form
    ]);
    await redisClient.sendCommand(['SADD', 'blogposts', postId.toString()]);

    // Respond with success message
    res.json({ success: true, message: 'Post created successfully' });
  } catch (err) {
    console.error('Error creating post:', err);
    res.status(500).send('Error creating post');
  }
});

app.get('/create-post', (req, res) => {
  res.render('create-post');  // Render the create-post.ejs file
});


// Get the blogpost
app.get('/blogposts', async (req, res) => {
  console.log('Received request for /blogposts');
  console.log(req.session);

  if (!req.session.isLoggedIn) {
      return res.status(401).json({ error: 'User not logged in' });
  }

  try {
      const postIds = await redisClient.sendCommand(['SMEMBERS', 'blogposts']);
      const posts = [];

      for (let id of postIds) {
          const postArray = await redisClient.sendCommand(['HGETALL', `blogposts:${id}`]);
          if (postArray) {
              const post = {};
              for (let i = 0; i < postArray.length; i += 2) {
                  post[postArray[i]] = postArray[i + 1];
              }
              posts.push({ id, ...post });
          }
      }

      
      res.render('pages/blogposts', {
          posts: posts,
          user: req.session.username 
      });

  } catch (err) {
      console.error('Error fetching posts:', err);
      res.status(500).send('Error fetching posts');
  }
});





app.post('/delete-post', async (req, res) => {
  const { postId } = req.body;
  const username = req.session.username;

  try {
      const postAuthor = await redisClient.hGet(`post:${postId}`, 'author');
      if (postAuthor === username) {
          // Corrected deletion
        await redisClient.del(`blogposts:${postId}`);
        await redisClient.sRem('blogposts', postId);

          res.redirect('/protected');
      } else {
          res.status(403).send('You can only delete your own posts');
      }
  } catch (err) {
      console.error('Error deleting post:', err);
      res.status(500).send('Error deleting post');
  }
});

app.get('/logout', (req, res) => {
  // Destroy the session to log the user out
  req.session.destroy((err) => {
      if (err) {
          console.error('Error logging out:', err);
          res.status(500).send('Error logging out');
      } else {
          res.status(200).send('You are logged out');
      }
  });
});








app.listen(PORT,"127.0.0.1", () => {
  console.log(`App listening on port ${PORT}`);
});
